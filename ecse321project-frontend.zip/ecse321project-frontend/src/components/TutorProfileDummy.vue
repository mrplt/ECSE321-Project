<template>
  <div id="tutorProfileDummy">
    <b-navbar type="dark" variant="dark">
      <b-navbar-nav>
        <b-nav-item id="logout" v-on:click="logout">Logout</b-nav-item>
        <b-nav-item v-on:click="gotohome">Home</b-nav-item>
        <b-nav-form>
          <b-form-input type="search" v-model="searchWord" id="searchWord" name="searchWord" class="mr-sm-2" placeholder="Search"></b-form-input>
          <b-button variant="outline-success" class="my-2 my-sm-0" type="submit" v-on:click="search">Search</b-button>
        </b-nav-form>
      </b-navbar-nav>
    </b-navbar>
    <div id="tutorProfileDummy">
      <b-container>
	  <b-row>
	  <b-col>
	  <br><img src="../assets/avatar.png" alt="Course not found" width=200 height=200>
      </b-col>
		<b-col>
		<br>
		<h1><b>Jane Doe</b></h1>
		<h2>4.3/5.0</h2>
		<h2> 25$/hour </h2>
		<button class="button" type="submit" variant="primary" v-on:click="submitbooking">Book A Session!</button>
	  </b-col>
	  </b-row>
	  </b-container>
      <b-container class="bv-example-row">
      <b-row>
          <b-col>
		  <div class="textbox">
		  <h1><u>Tutor Schedule</u></h1>
		  <br>
		  <h4>buraya bir takvim ittirmek lazim</h4>
		  </div>
		  </b-col>
		  <b-col>
		  <div class="textbox">
		  <h1><u>Courses</u></h1>
		  <h4> <b>Calculus I</b> <br>(MATH 140) </h4>
		  <h4> <b>Calculus II</b> <br>(MATH 141) </h4>
		  <h4> <b>Calculus III </b><br>(MATH 262) </h4>
		  <h4> <b>Intro to Software Engineering</b> <br>(ECSE 321) </h4>
		  </div>
		  </b-col>
	  </b-row>
	  </b-container>
	  <br>
	  <br>
	  <br>
	  <br>
      <br>	
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
	  <br>
      <br>	  
	 <h1><u>Reviews</u></h1>
	 <br>
	  <h2> Onur </h2>
	  <h4>"Explained in a great way,relly helped me understand the topic."</h4>
	  <h2>Murat </h2>
	  <h4> "He explained confusiniig concepts in a very understandable way"</h4>
	  <h2>Mairead</h2>
	  <h4> "Very good at explaining concepts. Easy to work with."</h4> 
    </div>
  </div>
</template>
<script>
import axios from 'axios'
var config = require('../../config')

var frontendUrl = 'http://' + config.dev.host + ':' + config.dev.port
var backendUrl = 'http://' + config.dev.backendHost + ':' + config.dev.backendPort

var AXIOS = axios.create({
  baseURL: backendUrl,
  headers: { 'Access-Control-Allow-Origin': frontendUrl }
})

function getUser() {
  AXIOS.get('/profile')
  .then(response => {
    this.currentUser = response.data;
  })
  .catch(e => {
    window.alert(e)
  })
}

export default {
  name: 'tutorProfileDummy',

  data() {
    return {
      currentUser: 'null',
      fields: '',
      items: '',
    }
  },
  created: function() {
    getUser()
  },
  methods: {
    gotohome: function() {
      window.location.href = '/'
    },
  }
}
</script>
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
}
.textbox{
  padding: 10px 20px;
  
  height: 30px;
  margin-right: auto;
  margin-left: auto;
 }
 </style>
